# Smart Prompt Camera — Semi-Ready Production Starter

Cross-platform teleprompter + camera app for Android and iOS.

## Design direction
This project takes inspiration from the *feature model* of modern teleprompter apps:
- script library
- camera + teleprompter in one screen
- smooth auto-scroll
- speed control
- font/spacing controls
- horizontal/vertical mirror
- countdown
- front/rear camera
- landscape/portrait
- local/offline scripts
- import TXT
- video preview and local save

It intentionally does **not** copy the original app's proprietary assets, screenshots, branding, source code, or exact UI. The UI is an original Smart Prompt Camera implementation so it can be customized further.

Reference feature set reviewed from Google Play:
https://play.google.com/store/apps/details?id=com.mkapp.teleprompter

## Stack
- Expo SDK 54
- React Native
- TypeScript
- Expo Router
- expo-camera
- expo-video
- expo-file-system
- expo-document-picker
- AsyncStorage
- FastAPI backend scaffold (optional)

## Run mobile app

```bash
npm install
npx expo start
```

For real camera/video recording, use a development build:

```bash
npx expo prebuild
npx expo run:android
npx expo run:ios
```

Expo Go can be used for UI development, but native recording features are best tested with a development build.

## Backend (optional)

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Copy `.env.example` to `.env` and set the mobile API URL if backend integration is enabled.

## What is intentionally left for production credentials
- Apple Developer signing
- Google Play signing
- RevenueCat / App Store / Play Billing product IDs
- production API URL
- production database
- privacy policy URL
- terms URL
- company legal details

## V1 roadmap
1. Device testing on physical Android + iPhone
2. Fix camera aspect/resolution per device
3. Add RevenueCat entitlement
4. Add Google/Apple sign-in
5. Add cloud script sync
6. Add TXT/DOCX/PDF parsers
7. Add voice-follow / speech recognition as a separate premium feature
8. Store listing assets
