# Feature Matrix

| Feature | V1 scaffold | Production |
|---|---:|---:|
| Script creation | YES | YES |
| Script editing | YES | YES |
| Local script storage | YES | YES |
| TXT import | YES | YES |
| Teleprompter | YES | YES |
| Auto scroll | YES | YES |
| Speed control | YES | YES |
| Font size | YES | YES |
| Mirror X/Y | YES | YES |
| Countdown | YES | YES |
| Front/rear camera | YES | YES |
| Video recording | YES | YES |
| Video library | TODO | YES |
| Video preview | TODO | YES |
| Cloud sync | scaffold | YES |
| Google/Apple login | TODO | YES |
| RevenueCat billing | scaffold | YES |
| Voice-follow | TODO | Premium V2 |
| DOCX import | TODO | V2 |
| PDF import | TODO | V2 |
| Wear OS remote | TODO | V2 |
| Bluetooth remote | TODO | V2 |
