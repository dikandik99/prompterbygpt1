# Production Checklist

## Mobile
- [ ] Test Android physical devices
- [ ] Test iPhone physical devices
- [ ] Test front/rear camera
- [ ] Test microphone
- [ ] Test portrait
- [ ] Test landscape
- [ ] Test low-memory device
- [ ] Test long recording
- [ ] Test interrupted recording
- [ ] Test phone call interruption
- [ ] Test Bluetooth keyboard
- [ ] Add crash reporting

## Billing
- [ ] Create App Store subscription products
- [ ] Create Google Play subscription products
- [ ] Configure RevenueCat
- [ ] Add entitlements
- [ ] Add restore purchases
- [ ] Add purchase error handling
- [ ] Test sandbox purchases

## Backend
- [ ] PostgreSQL
- [ ] JWT/OAuth
- [ ] User table
- [ ] Script sync
- [ ] Subscription webhook
- [ ] Rate limiting
- [ ] HTTPS
- [ ] Logging

## Store
- [ ] App icon
- [ ] Splash
- [ ] Screenshots
- [ ] Privacy policy
- [ ] Terms of service
- [ ] Data safety form
- [ ] App Store privacy labels
- [ ] Content rating
- [ ] Support URL
