import { router } from "expo-router";
import { useEffect } from "react";
import { View, ActivityIndicator } from "react-native";

export default function Index() {
  useEffect(() => {
    router.replace("/home");
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: "#090A0C", alignItems: "center", justifyContent: "center" }}>
      <ActivityIndicator color="#FFFFFF" />
    </View>
  );
}
