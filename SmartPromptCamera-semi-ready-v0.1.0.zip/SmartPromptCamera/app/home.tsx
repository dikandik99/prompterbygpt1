import { useFocusEffect } from "@react-navigation/native";
import { router } from "expo-router";
import { useCallback, useState } from "react";
import { Alert, FlatList, Pressable, SafeAreaView, Text, TextInput, View } from "react-native";
import { Script, createScript, deleteScript, listScripts } from "../lib/storage";

export default function Home() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [query, setQuery] = useState("");

  const refresh = useCallback(() => {
    listScripts().then(setScripts);
  }, []);

  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  const filtered = scripts.filter(s => s.title.toLowerCase().includes(query.toLowerCase()));

  const add = async () => {
    const s = await createScript("New Script", "Start writing your script here...");
    router.push({ pathname: "/editor", params: { id: s.id } });
  };

  const remove = (id: string) => {
    Alert.alert("Delete script?", "This cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => { await deleteScript(id); refresh(); } }
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#090A0C" }}>
      <View style={{ padding: 20, paddingBottom: 10 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <View>
            <Text style={{ color: "#FFF", fontSize: 28, fontWeight: "800" }}>Smart Prompt</Text>
            <Text style={{ color: "#8E949D", marginTop: 3 }}>Camera & Teleprompter</Text>
          </View>
          <Pressable onPress={() => router.push("/settings")} style={{ padding: 10 }}>
            <Text style={{ color: "#FFF", fontSize: 22 }}>⚙</Text>
          </Pressable>
        </View>

        <View style={{ marginTop: 18, backgroundColor: "#15171B", borderRadius: 14, paddingHorizontal: 14 }}>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search scripts"
            placeholderTextColor="#6F747D"
            style={{ color: "#FFF", height: 48 }}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={x => x.id}
        contentContainerStyle={{ padding: 20, paddingTop: 8 }}
        ListHeaderComponent={
          <Pressable onPress={add} style={{ backgroundColor: "#FFF", borderRadius: 14, padding: 16, marginBottom: 16 }}>
            <Text style={{ fontSize: 16, fontWeight: "800", color: "#090A0C" }}>＋ Create Script</Text>
          </Pressable>
        }
        ListEmptyComponent={<Text style={{ color: "#70757D", textAlign: "center", marginTop: 30 }}>No scripts yet.</Text>}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => router.push({ pathname: "/editor", params: { id: item.id } })}
            onLongPress={() => remove(item.id)}
            style={{ backgroundColor: "#15171B", borderRadius: 16, padding: 16, marginBottom: 10 }}
          >
            <Text style={{ color: "#FFF", fontWeight: "700", fontSize: 17 }}>{item.title}</Text>
            <Text numberOfLines={2} style={{ color: "#8E949D", marginTop: 7, lineHeight: 20 }}>{item.content}</Text>
            <Text style={{ color: "#5F646C", marginTop: 10, fontSize: 12 }}>Long press to delete</Text>
          </Pressable>
        )}
      />
    </SafeAreaView>
  );
}
