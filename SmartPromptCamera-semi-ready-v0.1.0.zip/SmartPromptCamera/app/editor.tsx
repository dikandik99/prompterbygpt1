import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, SafeAreaView, Text, TextInput, View } from "react-native";
import { getScript, saveScript } from "../lib/storage";

export default function Editor() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  useEffect(() => {
    if (id) getScript(id).then(s => { if (s) { setTitle(s.title); setContent(s.content); } });
  }, [id]);

  const save = async () => {
    if (!id) return;
    await saveScript({ id, title: title.trim() || "Untitled Script", content });
    router.back();
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#090A0C" }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", padding: 18 }}>
        <Pressable onPress={() => router.back()}><Text style={{ color: "#FFF", fontSize: 16 }}>Cancel</Text></Pressable>
        <Pressable onPress={save}><Text style={{ color: "#FFF", fontSize: 16, fontWeight: "800" }}>Save</Text></Pressable>
      </View>
      <View style={{ padding: 18, flex: 1 }}>
        <TextInput value={title} onChangeText={setTitle} placeholder="Script title" placeholderTextColor="#656A72"
          style={{ color: "#FFF", fontSize: 25, fontWeight: "800", marginBottom: 18 }} />
        <TextInput
          value={content}
          onChangeText={setContent}
          multiline
          textAlignVertical="top"
          placeholder="Write your script..."
          placeholderTextColor="#656A72"
          style={{ flex: 1, backgroundColor: "#15171B", borderRadius: 16, padding: 16, color: "#FFF", fontSize: 18, lineHeight: 28 }}
        />
        <Pressable
          onPress={async () => { await saveScript({ id: id!, title: title || "Untitled Script", content }); router.push({ pathname: "/prompter", params: { id } }); }}
          style={{ backgroundColor: "#FFF", borderRadius: 14, padding: 16, marginTop: 14 }}
        >
          <Text style={{ color: "#090A0C", fontWeight: "800", textAlign: "center" }}>Open Teleprompter</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
