import { router } from "expo-router";
import { Pressable, SafeAreaView, Text, View } from "react-native";

export default function Subscription() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#090A0C", padding: 20 }}>
      <Pressable onPress={() => router.back()}><Text style={{ color: "#FFF", fontSize: 30 }}>‹</Text></Pressable>
      <Text style={{ color: "#FFF", fontSize: 32, fontWeight: "900", marginTop: 30 }}>Go Pro</Text>
      <Text style={{ color: "#8D939C", marginTop: 8, fontSize: 16 }}>Unlock the full creator workflow.</Text>
      {["Unlimited scripts", "Advanced teleprompter controls", "Premium recording tools", "Cloud sync (coming)", "Priority support"].map(x => (
        <Text key={x} style={{ color: "#FFF", fontSize: 17, marginTop: 18 }}>✓  {x}</Text>
      ))}
      <View style={{ flexDirection: "row", gap: 12, marginTop: 30 }}>
        <View style={{ flex: 1, backgroundColor: "#15171B", padding: 18, borderRadius: 16 }}>
          <Text style={{ color: "#FFF", fontWeight: "800" }}>Monthly</Text>
          <Text style={{ color: "#FFF", fontSize: 24, fontWeight: "900", marginTop: 10 }}>Rp249K</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: "#FFF", padding: 18, borderRadius: 16 }}>
          <Text style={{ color: "#090A0C", fontWeight: "800" }}>Yearly</Text>
          <Text style={{ color: "#090A0C", fontSize: 24, fontWeight: "900", marginTop: 10 }}>Rp1.199M</Text>
        </View>
      </View>
      <Pressable onPress={() => {}} style={{ marginTop: 18, backgroundColor: "#FFF", padding: 17, borderRadius: 14 }}>
        <Text style={{ textAlign: "center", fontWeight: "900", color: "#090A0C" }}>Continue</Text>
      </Pressable>
      <Text style={{ color: "#646A73", textAlign: "center", marginTop: 12, fontSize: 12 }}>Billing adapter is intentionally left for App Store / Google Play / RevenueCat production credentials.</Text>
    </SafeAreaView>
  );
}
