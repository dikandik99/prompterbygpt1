import { useLocalSearchParams, router } from "expo-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import { getScript } from "../lib/storage";

export default function Prompter() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [content, setContent] = useState("");
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [fontSize, setFontSize] = useState(34);
  const [mirrorX, setMirrorX] = useState(false);
  const [mirrorY, setMirrorY] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const y = useRef(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (id) getScript(id).then(s => s && setContent(s.content));
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [id]);

  useEffect(() => {
    if (timer.current) clearInterval(timer.current);
    if (playing) {
      timer.current = setInterval(() => {
        y.current += 1.5 * speed;
        scrollRef.current?.scrollTo({ y: y.current, animated: false });
      }, 40);
    }
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [playing, speed]);

  const transform = useMemo(() => [
    { scaleX: mirrorX ? -1 : 1 },
    { scaleY: mirrorY ? -1 : 1 }
  ], [mirrorX, mirrorY]);

  return (
    <SafeAreaView style={styles.root}>
      <View style={styles.top}>
        <Pressable onPress={() => router.back()}><Text style={styles.topText}>‹</Text></Pressable>
        <Text style={styles.title}>Teleprompter</Text>
        <Pressable onPress={() => router.push({ pathname: "/camera", params: { id } })}>
          <Text style={styles.record}>● Camera</Text>
        </Pressable>
      </View>

      <View style={styles.promptArea}>
        <ScrollView ref={scrollRef} contentContainerStyle={{ paddingHorizontal: 22, paddingTop: 80, paddingBottom: 600 }}>
          <Text style={[styles.script, { fontSize, lineHeight: fontSize * 1.45, transform }]}>{content}</Text>
        </ScrollView>
      </View>

      <View style={styles.controls}>
        <Pressable style={styles.control} onPress={() => setSpeed(Math.max(0.25, +(speed - 0.25).toFixed(2)))}><Text style={styles.controlText}>−</Text></Pressable>
        <Text style={styles.value}>{speed.toFixed(2)}×</Text>
        <Pressable style={styles.control} onPress={() => setSpeed(Math.min(4, +(speed + 0.25).toFixed(2)))}><Text style={styles.controlText}>＋</Text></Pressable>
        <Pressable style={styles.play} onPress={() => setPlaying(v => !v)}><Text style={styles.playText}>{playing ? "Ⅱ" : "▶"}</Text></Pressable>
        <Pressable style={styles.control} onPress={() => setFontSize(Math.max(20, fontSize - 2))}><Text style={styles.controlText}>A−</Text></Pressable>
        <Pressable style={styles.control} onPress={() => setFontSize(Math.min(70, fontSize + 2))}><Text style={styles.controlText}>A＋</Text></Pressable>
        <Pressable style={styles.control} onPress={() => setMirrorX(v => !v)}><Text style={styles.controlText}>↔</Text></Pressable>
        <Pressable style={styles.control} onPress={() => setMirrorY(v => !v)}><Text style={styles.controlText}>↕</Text></Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#050506" },
  top: { height: 58, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16 },
  topText: { color: "#FFF", fontSize: 38 },
  title: { color: "#FFF", fontWeight: "800", fontSize: 17 },
  record: { color: "#FF4D5A", fontWeight: "800" },
  promptArea: { flex: 1, overflow: "hidden" },
  script: { color: "#FFF", fontWeight: "700" },
  controls: { minHeight: 76, backgroundColor: "#121318", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 8 },
  control: { backgroundColor: "#202229", borderRadius: 10, paddingHorizontal: 11, paddingVertical: 10 },
  controlText: { color: "#FFF", fontWeight: "700" },
  value: { color: "#FFF", minWidth: 45, textAlign: "center" },
  play: { backgroundColor: "#FFF", borderRadius: 40, width: 52, height: 52, alignItems: "center", justifyContent: "center", marginHorizontal: 4 },
  playText: { color: "#090A0C", fontWeight: "900" }
});
