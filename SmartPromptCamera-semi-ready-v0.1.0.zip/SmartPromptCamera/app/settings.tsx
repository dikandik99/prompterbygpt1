import { router } from "expo-router";
import { Pressable, SafeAreaView, Text, View } from "react-native";

export default function Settings() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#090A0C", padding: 20 }}>
      <Pressable onPress={() => router.back()}><Text style={{ color: "#FFF", fontSize: 30 }}>‹</Text></Pressable>
      <Text style={{ color: "#FFF", fontSize: 30, fontWeight: "800", marginTop: 20 }}>Settings</Text>
      <View style={{ marginTop: 25, backgroundColor: "#15171B", borderRadius: 16, padding: 18 }}>
        <Text style={{ color: "#FFF", fontSize: 17, fontWeight: "700" }}>Smart Prompt Camera</Text>
        <Text style={{ color: "#777D86", marginTop: 6 }}>Version 0.1.0 — semi-ready build</Text>
      </View>
      <Pressable onPress={() => router.push("/subscription")} style={{ marginTop: 12, backgroundColor: "#FFF", padding: 16, borderRadius: 14 }}>
        <Text style={{ color: "#090A0C", textAlign: "center", fontWeight: "800" }}>Upgrade to Pro</Text>
      </Pressable>
    </SafeAreaView>
  );
}
