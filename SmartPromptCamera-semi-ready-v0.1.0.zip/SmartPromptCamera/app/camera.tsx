import { CameraView, useCameraPermissions, useMicrophonePermissions } from "expo-camera";
import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { Alert, Pressable, SafeAreaView, StyleSheet, Text, View } from "react-native";
import { getScript } from "../lib/storage";

export default function CameraScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const camera = useRef<CameraView>(null);
  const [camPerm, requestCam] = useCameraPermissions();
  const [micPerm, requestMic] = useMicrophonePermissions();
  const [facing, setFacing] = useState<"front" | "back">("front");
  const [recording, setRecording] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [script, setScript] = useState("");
  const [fontSize, setFontSize] = useState(25);
  const [speed, setSpeed] = useState(1);
  const [playing, setPlaying] = useState(false);
  const [offset, setOffset] = useState(0);

  useEffect(() => { if (id) getScript(id).then(s => s && setScript(s.content)); }, [id]);

  if (!camPerm || !micPerm) return <View style={styles.center}><Text style={styles.white}>Loading permissions…</Text></View>;
  if (!camPerm.granted) return <View style={styles.center}><Text style={styles.white}>Camera permission is required.</Text><Pressable onPress={requestCam}><Text style={styles.link}>Grant camera</Text></Pressable></View>;
  if (!micPerm.granted) return <View style={styles.center}><Text style={styles.white}>Microphone permission is required.</Text><Pressable onPress={requestMic}><Text style={styles.link}>Grant microphone</Text></Pressable></View>;

  const startRecording = async () => {
    if (recording) {
      camera.current?.stopRecording();
      setRecording(false);
      setPlaying(false);
      return;
    }
    setCount(3);
    let n = 3;
    const interval = setInterval(() => {
      n -= 1;
      if (n <= 0) {
        clearInterval(interval);
        setCount(null);
        setRecording(true);
        camera.current?.recordAsync({ maxDuration: 900 });
      } else setCount(n);
    }, 1000);
  };

  return (
    <SafeAreaView style={styles.root}>
      <CameraView ref={camera} style={StyleSheet.absoluteFill} facing={facing} mode="video" />

      <View style={styles.overlay}>
        <View style={styles.top}>
          <Pressable onPress={() => router.back()}><Text style={styles.icon}>×</Text></Pressable>
          <Text style={styles.badge}>{recording ? "REC" : "READY"}</Text>
          <Pressable onPress={() => setFacing(f => f === "front" ? "back" : "front")}><Text style={styles.icon}>↻</Text></Pressable>
        </View>

        <View style={styles.promptWindow}>
          <Text style={[styles.prompt, { fontSize }]}>{script.slice(Math.max(0, offset), offset + 700)}</Text>
        </View>

        {count !== null && <View style={styles.count}><Text style={styles.countText}>{count}</Text></View>}

        <View style={styles.bottom}>
          <View style={styles.row}>
            <Pressable onPress={() => setSpeed(Math.max(.25, speed-.25))} style={styles.small}><Text style={styles.white}>−</Text></Pressable>
            <Text style={styles.white}>{speed.toFixed(2)}×</Text>
            <Pressable onPress={() => setSpeed(Math.min(4, speed+.25))} style={styles.small}><Text style={styles.white}>＋</Text></Pressable>
            <Pressable onPress={() => setFontSize(Math.max(18,fontSize-2))} style={styles.small}><Text style={styles.white}>A−</Text></Pressable>
            <Pressable onPress={() => setFontSize(Math.min(50,fontSize+2))} style={styles.small}><Text style={styles.white}>A＋</Text></Pressable>
          </View>
          <View style={styles.row}>
            <Pressable onPress={() => setPlaying(v => !v)} style={styles.small}><Text style={styles.white}>{playing ? "Ⅱ" : "▶"}</Text></Pressable>
            <Pressable onPress={() => setOffset(o => Math.max(0,o-100))} style={styles.small}><Text style={styles.white}>‹</Text></Pressable>
            <Pressable onPress={startRecording} style={[styles.shutter, recording && { borderColor: "#FF4D5A" }]}>
              <View style={[styles.shutterInner, recording && { backgroundColor: "#FF4D5A", borderRadius: 8 }]} />
            </Pressable>
            <Pressable onPress={() => setOffset(o => Math.min(Math.max(0,script.length-700),o+100))} style={styles.small}><Text style={styles.white}>›</Text></Pressable>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root:{flex:1,backgroundColor:"#000"}, overlay:{...StyleSheet.absoluteFillObject,justifyContent:"space-between"},
  top:{height:60,flexDirection:"row",justifyContent:"space-between",alignItems:"center",paddingHorizontal:18},
  icon:{color:"#FFF",fontSize:32}, badge:{color:"#FFF",backgroundColor:"rgba(0,0,0,.55)",paddingHorizontal:12,paddingVertical:6,borderRadius:20,fontWeight:"800"},
  promptWindow:{marginHorizontal:18,marginTop:30,maxHeight:"52%",backgroundColor:"rgba(0,0,0,.28)",borderRadius:18,padding:18,overflow:"hidden"},
  prompt:{color:"#FFF",fontWeight:"800",lineHeight:38,textAlign:"center",textShadowColor:"#000",textShadowRadius:5},
  count:{position:"absolute",top:"40%",alignSelf:"center",backgroundColor:"rgba(0,0,0,.7)",width:110,height:110,borderRadius:55,alignItems:"center",justifyContent:"center"},
  countText:{color:"#FFF",fontSize:58,fontWeight:"900"}, bottom:{padding:14,backgroundColor:"rgba(0,0,0,.55)",gap:12},row:{flexDirection:"row",alignItems:"center",justifyContent:"center",gap:12},
  small:{backgroundColor:"rgba(30,32,38,.9)",paddingHorizontal:14,paddingVertical:10,borderRadius:12}, white:{color:"#FFF",fontWeight:"700"},
  shutter:{width:70,height:70,borderRadius:35,borderWidth:5,borderColor:"#FFF",alignItems:"center",justifyContent:"center"}, shutterInner:{width:52,height:52,borderRadius:26,backgroundColor:"#FFF"}
});
