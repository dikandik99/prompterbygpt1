from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Smart Prompt Camera API", version="0.1.0")

class Health(BaseModel):
    status: str
    version: str

@app.get("/health", response_model=Health)
def health():
    return {"status": "ok", "version": "0.1.0"}

@app.get("/api/v1/config")
def config():
    return {
        "app": "Smart Prompt Camera",
        "subscription": {
            "monthly": "spc_monthly",
            "yearly": "spc_yearly"
        },
        "features": {
            "cloud_sync": False,
            "voice_scroll": False
        }
    }

# Production TODO:
# - OAuth/Apple/Google authentication
# - User database
# - Script sync
# - RevenueCat webhook validation
# - Subscription entitlement endpoint
# - S3/object storage for optional cloud recordings
