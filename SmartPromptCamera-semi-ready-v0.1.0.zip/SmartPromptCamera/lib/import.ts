import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";

export async function importTextFile() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["text/plain", "text/*"],
    copyToCacheDirectory: true
  });
  if (result.canceled) return null;
  const uri = result.assets[0].uri;
  const text = await FileSystem.readAsStringAsync(uri);
  return { name: result.assets[0].name, text };
}
