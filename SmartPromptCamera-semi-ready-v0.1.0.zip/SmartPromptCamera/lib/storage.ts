import AsyncStorage from "@react-native-async-storage/async-storage";

export type Script = { id: string; title: string; content: string; updatedAt: string };
const KEY = "spc_scripts_v1";

async function all(): Promise<Script[]> {
  const raw = await AsyncStorage.getItem(KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function listScripts() { return (await all()).sort((a,b) => b.updatedAt.localeCompare(a.updatedAt)); }
export async function getScript(id: string) { return (await all()).find(x => x.id === id) ?? null; }

export async function createScript(title: string, content: string) {
  const item = { id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, title, content, updatedAt: new Date().toISOString() };
  await AsyncStorage.setItem(KEY, JSON.stringify([item, ...(await all())]));
  return item;
}

export async function saveScript(item: Omit<Script, "updatedAt">) {
  const list = await all();
  const next = { ...item, updatedAt: new Date().toISOString() };
  const idx = list.findIndex(x => x.id === item.id);
  if (idx >= 0) list[idx] = next; else list.unshift(next);
  await AsyncStorage.setItem(KEY, JSON.stringify(list));
}

export async function deleteScript(id: string) {
  await AsyncStorage.setItem(KEY, JSON.stringify((await all()).filter(x => x.id !== id)));
}
